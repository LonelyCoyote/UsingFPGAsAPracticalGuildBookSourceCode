/*********************************************************************
Implements a serial communications using ASCI commands with null
terminators to and from the PC
*********************************************************************/
#ifndef SRC_PCCOMM_H_
#define SRC_PCCOMM_H_

// Reads the next command sent from the PC, note: this function
// will block until the command is sent
// returns a null terminated string
const char* PCComm_ReadNextCommand();

// Sends a command, returns right away, does not wait for the
// command being sent to be completed
void PCComm_SendCommand(const char* pCmd);


#endif

// EOF ***************************************************************
