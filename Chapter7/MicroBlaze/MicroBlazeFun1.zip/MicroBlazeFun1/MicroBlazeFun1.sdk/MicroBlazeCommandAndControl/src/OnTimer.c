/*************************************************************************
*************************************************************************/
#include "OnTimer.h"

static const char* ConvertUnsignedIntToAsci(unsigned int number);
static void append(char* pTarget,const char* pNew);
static int strLength(const char* pStr);

/*************************************************************************
*************************************************************************/
double OnTimer_Time()
{
	static const double twoToThePowerOf32=4294967296.0;
	static const double countsPerMicroSecond=48e6;
	unsigned int lower;
	unsigned int upper;
	OnTimer_RawTime(&lower,&upper);
	double result=upper*twoToThePowerOf32+(double)lower;
	result/=countsPerMicroSecond;
	return result;
}

/*************************************************************************
*************************************************************************/
void OnTimer_RawTime(unsigned int* pLower,unsigned int* pUpper)
{
	static volatile unsigned int* const pTmr=(unsigned int*)0xC0002000;

	// Latch the data on a write
	*pTmr=0;

	// Read the lower and upper words
	*pLower=*pTmr;
	*pUpper=*pTmr;
}

/*************************************************************************
*************************************************************************/
const char* OnTimer_InHoursMinutesSeconds()
{
	static char pData[1023];
	*pData=0;
	double time=OnTimer_Time();
	const unsigned int hours=time/3600;
	time-=hours*3600.0;
	const unsigned int minutes=time/60;
	time-=minutes*60.0;
	const unsigned int seconds=time;
	const double fraction=time-seconds;
	const unsigned int microSeconds=fraction*1e6;
	const char* pNext=ConvertUnsignedIntToAsci(hours);
	if(strLength(pNext)==1) append(pData,"0");
	append(pData,pNext);
	append(pData,":");
	pNext=ConvertUnsignedIntToAsci(minutes);
	if(strLength(pNext)==1) append(pData,"0");
	append(pData,pNext);
	append(pData,":");
	pNext=ConvertUnsignedIntToAsci(seconds);
	if(strLength(pNext)==1) append(pData,"0");
	append(pData,pNext);
	append(pData,".");
	pNext=ConvertUnsignedIntToAsci(microSeconds);
	int appendNumber=6-strLength(pNext);
	for(int x=0;x<appendNumber;x++)
	{
		append(pData,"0");
	}
	append(pData,ConvertUnsignedIntToAsci(microSeconds));
	return pData;
}

/*************************************************************************
*************************************************************************/
static const char* ConvertUnsignedIntToAsci(unsigned int number)
{
    static char pData[1024];
    char* pNext=pData+1023;
    *pNext=0;
    if(number==0)
    {
        pNext--;
    	*pNext=0x30;
        return pNext;
    }
    while(number!=0)
    {
        pNext--;
    	*pNext=0x30+number%10;
        number/=10;
    }
    return pNext;
}

/*************************************************************************
*************************************************************************/
static void append(char* pTarget,const char* pNew)
{
    while(*pTarget!=0) { pTarget++; };
    while(*pNew!=0)
    {
        *pTarget++=*pNew++;
    }
    *pTarget=0;
}

/*************************************************************************
*************************************************************************/
static int strLength(const char* pStr)
{
	int len=0;
	while(*pStr++!=0){len++;}
	return len;
}


// EOF *****************************************************************




