/************************************************************************
************************************************************************/
#include "CountdownTimer.h"
#include "OnTimer.h"

typedef struct
{
	double timeInterval;
	double nextOverTime;
}COUNT_DOWN_TIMER_DATA;

static COUNT_DOWN_TIMER_DATA Timers[COUNTDOWN_TIMER_NUMBER_OF_TIMERS];

// Sets the specified timer with a timeOut value in microseconds
void CountDownTimer_SetTimer(int timerNumber,double timeOut)
{
	if(timerNumber>=COUNTDOWN_TIMER_NUMBER_OF_TIMERS) return;
	Timers[timerNumber].timeInterval=timeOut;
	Timers[timerNumber].nextOverTime=OnTimer_Time()+timeOut;
}


// Returns 1 if the timer time is over, 0 otherwise
// Side effect:  Resets the timer for another interval if time is up
int CountDownTimer_TimeIsUp(int timerNumber)
{
	if(timerNumber>=COUNTDOWN_TIMER_NUMBER_OF_TIMERS) return 0;
	if(OnTimer_Time()>=Timers[timerNumber].nextOverTime)
	{
		Timers[timerNumber].nextOverTime=
				OnTimer_Time()+Timers[timerNumber].timeInterval;
		return 1;
	}
	return 0;
}

// EOF ***********************************************************



