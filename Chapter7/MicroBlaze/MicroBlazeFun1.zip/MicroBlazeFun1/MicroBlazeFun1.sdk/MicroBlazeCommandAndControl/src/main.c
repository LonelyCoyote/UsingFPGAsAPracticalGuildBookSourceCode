/******************************************************************************
******************************************************************************/
#include "platform.h"
#include "PCComm.h"
#include "OnTimer.h"
#include "CountdownTimer.h"


void app();
void ContinuousProcessingLoop();
int CommandIs(const char* pCmd,const char* pCCmd);

/******************************************************************************
Initializes things and calls app() to run the application
******************************************************************************/
int main()
{
    init_platform();
    app();
    cleanup_platform();
    return 0;
}

/******************************************************************************
Application code goes here
******************************************************************************/
void app()
{
	// Setup any timers we want to use in our application
	CountDownTimer_SetTimer(0,0.06);

	while(1)
	{
		const char* command=PCComm_ReadNextCommand();

		if(*command==0)
		{
			ContinuousProcessingLoop();
			continue;
		}

		if(CommandIs(command,"HELLO"))
		{
			PCComm_SendCommand("HI THERE!");
			continue;
		}

		if(CommandIs(command,"ONTIMER?"))
		{
			PCComm_SendCommand(OnTimer_InHoursMinutesSeconds());
			continue;
		}

		// Default behavior is to echo back the command
		PCComm_SendCommand(command);
	}
}

/******************************************************************************
Called during the time the processor is not processing a command from the PC
Place anything you want done repeatedly inside of this function.  Note:
To remain responsive to the main communications loop with the PC whatever
is done in here should not take a very long time.  I would recommend not
exceeding 10ms before returning
******************************************************************************/
void ContinuousProcessingLoop()
{
	// In this example we are having the LED's go back and forth
	// like in the Night Rider movie, if you know nothing about that movie
	// all it does is causes one LED to be on and to bounce back and forth
	// between the two limits
	static int ledNumber=0;
	static int direction=1;
	static unsigned int* const pLEDRegister=(unsigned int*)0x80000010;
	if(CountDownTimer_TimeIsUp(0))
	{
		*pLEDRegister=(unsigned int)(1<<ledNumber);
		if(ledNumber==7) direction=-1;
		if(ledNumber==0) direction=1;
		ledNumber+=direction;
	}
}

/******************************************************************************
returns 1 if the two buffers match, 0 if not
******************************************************************************/
int CommandIs(const char* pCmd,const char* pCCmd)
{
	while(*pCmd!=0 && *pCCmd!=0)
	{
		if(*pCmd!=*pCCmd) return 0;
		pCmd++; pCCmd++;
	}
	if(*pCmd==0 && *pCCmd==0) return 1;
	return 0;
}






// EOF ************************************************************************
