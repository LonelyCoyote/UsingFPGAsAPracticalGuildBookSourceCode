/***************************************************************************
***************************************************************************/
#ifndef ONTIMER_H
#define ONTIMER_H

// Returns the time (in seconds) that this processor has been on
double OnTimer_Time();

// Returns the raw time both upper and lower parts
void OnTimer_RawTime(unsigned int* pLower,unsigned int* pUpper);

// Returns the time (formatted) as a string- HH:MM:SS.SSSSSS
const char* OnTimer_InHoursMinutesSeconds();

#endif

// EOF ********************************************************************
