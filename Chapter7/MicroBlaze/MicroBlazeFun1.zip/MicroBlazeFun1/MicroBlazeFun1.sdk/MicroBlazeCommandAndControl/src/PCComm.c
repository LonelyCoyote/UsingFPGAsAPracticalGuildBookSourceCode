/***********************************************************************
***********************************************************************/
#include "PCComm.h"

static volatile unsigned int* const pPCMBCommCounters=(unsigned int*)0x80000024;
static volatile unsigned int* const pPCCommInOut=(unsigned int*)0xC0001000;


/***********************************************************************
***********************************************************************/
const char* PCComm_ReadNextCommand()
{
	static char cmdBuffer[1024];
	int maxCount=1024;
	cmdBuffer[0]=0;	// Null terminate the command buffer
	char* cmdBufferPtr=cmdBuffer;
	int done=0;

	// If there is nothing in the input buffer, do not block
	// but return a null string
	if(((*pPCMBCommCounters)&0x00FF)==0)
	{
		*cmdBuffer=0;
		return cmdBuffer;
	}

	while(1)
	{
		unsigned int dataCount=(*pPCMBCommCounters)&0x00FF;
		if(dataCount>0)
		{
			for(int x=0;x<dataCount;x++)
			{
				// Assure we do not go past the end of the buffer
				if((cmdBufferPtr-cmdBuffer)>maxCount-4)
				{
					done=1;
					break;
				}

				unsigned int nextWord=*pPCCommInOut;
				char b1=(char)(nextWord&0xFF);
				char b2=(char)((nextWord>>8)&0xFF);
				if(b1!=0)
				{
					*cmdBufferPtr++=b1;
				}
				else
				{
					done=1;
					break;
				}

				if(b2!=0)
				{
					*cmdBufferPtr++=b2;
				}
				else
				{
					done=1;
					break;
				}
			}
		}
		if(done==1)
		{
			*cmdBufferPtr=0;	// null terminate
			return cmdBuffer;
		}
	}
}

/***********************************************************************
***********************************************************************/
void PCComm_SendCommand(const char* pCmd)
{
	while(*pCmd!=0)
	{
		unsigned int word=(unsigned int)*pCmd++;
		if(*pCmd==0)
		{
			*pPCCommInOut=word;
			break;
		}
		word|=((unsigned int)(*pCmd))<<8;
		*pPCCommInOut=word;
		pCmd++;
	}
	*pPCCommInOut=0;	// null terminate
}

// EOF *****************************************************************



