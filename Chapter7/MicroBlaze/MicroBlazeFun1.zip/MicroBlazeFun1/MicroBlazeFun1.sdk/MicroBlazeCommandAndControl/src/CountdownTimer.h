/*************************************************************************
Use these for tasking that is non blocking but must occur periodically
at specified intervals
*************************************************************************/
#ifndef SRC_COUNTDOWNTIMER_H_
#define SRC_COUNTDOWNTIMER_H_

#define COUNTDOWN_TIMER_NUMBER_OF_TIMERS (5)

// Sets the specified timer with a timeOut value in seconds
void CountDownTimer_SetTimer(int timerNumber,double timeOut);


// Returns 1 if the timer time is over, 0 otherwise
// Side effect:  Resets the timer for another interval
int CountDownTimer_TimeIsUp(int timerNumber);

#endif /* SRC_COUNTDOWNTIMER_H_ */
